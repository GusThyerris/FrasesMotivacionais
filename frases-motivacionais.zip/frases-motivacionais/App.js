import { Text, SafeAreaView, StyleSheet, ScrollView } from 'react-native';
import { useFonts, Bangers_400Regular } from '@expo-google-fonts/bangers';
import { Balthazar_400Regular } from '@expo-google-fonts/balthazar';
import { Ballet_400Regular } from '@expo-google-fonts/ballet';
import { Chicle_400Regular } from '@expo-google-fonts/chicle';
import { Cookie_400Regular } from '@expo-google-fonts/cookie';
import { Actor_400Regular } from '@expo-google-fonts/actor';
import { Aladin_400Regular } from '@expo-google-fonts/aladin';
import { Allan_400Regular } from '@expo-google-fonts/allan';
import { Mina_400Regular } from '@expo-google-fonts/mina';
import { Nabla_400Regular } from '@expo-google-fonts/nabla';
import { Lemonada_600SemiBold } from '@expo-google-fonts/lemonada';

export default function App() {
  let [fontLoaded, fontError] = useFonts({
    Bangers_400Regular,
    Balthazar_400Regular,
    Ballet_400Regular,
    Chicle_400Regular,
    Cookie_400Regular,
    Actor_400Regular,
    Aladin_400Regular,
    Allan_400Regular,
    Mina_400Regular,
    Nabla_400Regular,
    Lemonada_600SemiBold
  });

  if (!fontLoaded && !fontError) {
    return null;
  }

  return (
    <ScrollView>
      <SafeAreaView style={styles.container}>
        <Text style={styles.titulo}>
          Assim como linhas de código constroem programas, suas ações moldam seu
          futuro na TI - escreva uma história épica de sucesso com determinação
          e resiliência.
        </Text>
        <Text style={styles.titulo2}>
          Na Tecnologia da Informação, cada desafio é uma oportunidade para
          criar soluções inovadoras.
        </Text>
        <Text style={styles.titulo3}>
          O mundo da TI é um universo de possibilidades, onde linhas de código
          se transformam em realizações extraordinárias.
        </Text>
        <Text style={styles.titulo4}>
          Em TI, o aprendizado é constante e as barreiras são apenas degraus
          para o sucesso.
        </Text>
        <Text style={styles.titulo5}>
          Assim como o código evolui, nós também crescemos através dos
          obstáculos que enfrentamos na TI.
        </Text>
        <Text style={styles.titulo6}>
          Na era digital, os profissionais de TI são os arquitetos do amanhã,
          construindo pontes entre a imaginação e a realidade.
        </Text>
        <Text style={styles.titulo7}>
          A paixão por resolver problemas é o combustível que impulsiona os
          corações dos amantes da TI.
        </Text>
        <Text style={styles.titulo8}>
          Em TI, não existem erros, apenas iterações em direção à perfeição.
        </Text>
        <Text style={styles.titulo9}>
          A colaboração é a base da TI; juntos, alcançamos a excelência que
          individualmente nunca alcançaríamos.
        </Text>
        <Text style={styles.titulo10}>
          No mundo da Tecnologia da Informação, cada challenge é uma
          oportunidade de code, debug e conquistar novos patamares de inovação.
        </Text>
        <Text style={styles.titulo11}>
          FRASE BONUS!!!!!{'\n'}{'\n'}Te amamos prof. Silvio Florentino{'\n'}{'\n'} By Gustavo Thyerris e Arthur
        </Text>
      </SafeAreaView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 8,
    backgroundColor:'#acacac'
  },
  titulo: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Bangers_400Regular',
  },
  titulo2: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Balthazar_400Regular',
  },
  titulo3: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Ballet_400Regular',
  },
  titulo4: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Chicle_400Regular',
  },
  titulo5: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Cookie_400Regular',
  },
  titulo6: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Actor_400Regular',
  },
  titulo7: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Aladin_400Regular',
  },
  titulo8: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Allan_400Regular',
  },
  titulo9: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Mina_400Regular',
  },
  titulo10: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Nabla_400Regular',
  },
    titulo11: {
    margin: 24,
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Lemonada_600SemiBold',
  },
});
